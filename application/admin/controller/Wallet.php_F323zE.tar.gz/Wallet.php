<?php
namespace app\admin\controller;


use think\Request;
use app\admin\model\MMutualAid;
use app\admin\model\MMutualAidOrder;
use app\admin\model\MMember;
use app\admin\model\MMemberMutual;
use think\Exception;
use think\Db;
use app\admin\model\MMutualAidLog;
use app\api\model\MConfig;
use app\admin\model\MMutualAidExamine;
use app\admin\model\MMemberLevel;
use app\admin\model\MMemberRechage;
use app\admin\model\MMemberWithdraw;

class Wallet extends Check
{   
    
    //充值记录
    public function tmNotificationList(Request $request){
        $type = intval($request->param('type', 0)); // 通道
        $status = intval($request->param('status', 0)); // 状态
        $serach = $request->param('serach', ''); // 关键字搜索  名称/龙珠/收益天数
        $add_time_s = $request->param('add_time_s', '');
        $add_time_e = $request->param('add_time_e', ''); 
        $allParams = ['query' => $request->param()];
        $this->assign('param_type', $type);
        $this->assign('param_status', $status);
        $this->assign('param_serach', $serach);
        $this->assign('param_add_time_s', $add_time_s);
        $this->assign('param_add_time_e', $add_time_e);
        $pageSize = 10; // 分页大小
        $where = '1 = 1'; // 初始查询条件
        if($status != 0){
            $where .= ' and `status` = '.$status;
        }
        if($type != 0){
            $where .= ' and `type` = '.$type;
        }
        if($serach != ''){
            $where .= ' and `hash` like \'%'.$serach.'%\' OR `user` like \'%'.$serach.'%\' OR `tel` like \'%'.$serach.'%\' OR `num` like \'%'.$serach.'%\'';
        }
        if ($add_time_s != '') {
            $where .= " and `create_time` >= " . strtotime($add_time_s);
        }
        if ($add_time_e != '') {
            $where .= " and `create_time` <= " . strtotime($add_time_e);
        }

        $MMemberRechage = new MMemberRechage();
        $list = $MMemberRechage->getlists($where, $pageSize, $allParams, 'id desc');
        foreach ($list as $k => $v){
            $list[$k]['create_time'] = $v['create_time'];//-9000;
            if($v['update_time'] > 0){
                $list[$k]['update_time'] = $v['update_time'];//-9000;
            }
        }
        $this->assign('orderList',$list);   
        
        $MConfig = new MConfig();
        $config_val = $MConfig->readConfig(['PAY_ONE','PAY_TWO','PAY_ONE_NAME','PAY_TWO_NAME','PAY_THREE','PAY_THREE_NAME','PAY_FOUR','PAY_FOUR_NAME'],2);
        $data = [];
        //if($config_val[0] == 1){
            $pay1 = $config_val[2];
        //}
        //if($config_val[1] == 1){
            $pay2 = $config_val[3];
        //}
        
            $pay3 = $config_val[5];
            $pay4 = $config_val[7];
        $this->assign('pay1',$pay1);
        $this->assign('pay2',$pay2);
        $this->assign('pay3',$pay3);
        $this->assign('pay4',$pay4);

        return view();
    }
    
    
    //提现记录
    public function tmWithdrawList(Request $request){
        $type = intval($request->param('type', 0)); // 通道
        $status = intval($request->param('status', 0)); // 状态
        $serach = $request->param('serach', ''); // 关键字搜索  名称/龙珠/收益天数
        $add_time_s = $request->param('add_time_s', '');
        $add_time_e = $request->param('add_time_e', '');
        $allParams = ['query' => $request->param()];
        $this->assign('param_type', $type);
        $this->assign('param_status', $status);
        $this->assign('param_serach', $serach);
        $this->assign('param_add_time_s', $add_time_s);
        $this->assign('param_add_time_e', $add_time_e);
        $pageSize = 10; // 分页大小
        $where = '1 = 1'; // 初始查询条件
        if($status != 0){
            $where .= ' and `status` = '.$status;
        }
        if($type != 0){
            $where .= ' and `type` = '.$type;
        }
        if($serach != ''){
            //$where .= ' and `name` like \'%'.$serach.'%\' OR `price` like \'%'.$serach.'%\' OR `rate` like \'%'.$serach.'%\'';
            $where .= ' and `user` like \'%'.$serach.'%\' OR `num` like \'%'.$serach.'%\' OR `tel` like \'%'.$serach.'%\' OR `order_id` like \'%'.$serach.'%\' OR `hash` like \'%'.$serach.'%\'';
        }
        if ($add_time_s != '') {
            $where .= " and `create_time` >= " . strtotime($add_time_s);
        }
        if ($add_time_e != '') {
            $where .= " and `create_time` <= " . strtotime($add_time_e);
        }
        
        $MMemberWithdraw = new MMemberWithdraw();
        $list = $MMemberWithdraw->getlists($where, $pageSize, $allParams, 'id desc');
        foreach ($list as $k => $v){
            $list[$k]['create_time'] = $v['create_time'];//-9000;
            if($v['update_time'] > 0){
                $list[$k]['update_time'] = $v['update_time'];//-9000;
            }
        }
        $this->assign('orderList',$list);
        
        $MConfig = new MConfig();
        $config_val = $MConfig->readConfig(['PAY_ONE','PAY_TWO','PAY_ONE_NAME','PAY_TWO_NAME','PAY_THREE','PAY_THREE_NAME','PAY_FOUR','PAY_FOUR_NAME'],2);
        $data = [];
        //if($config_val[0] == 1){
            $pay1 = $config_val[2];
        //}
        //if($config_val[1] == 1){
            $pay2 = $config_val[3];
        //}
        
        $pay3 = $config_val[5];
        $pay4 = $config_val[7];
        $this->assign('pay1',$pay1);
        $this->assign('pay2',$pay2);
        $this->assign('pay3',$pay3);
        $this->assign('pay4',$pay4);
        
        return view();
    }
    
    
    // 验证 通过/拒绝
    public function tmagree(Request $request)
    {
        $id = intval($request->param('id', 0)); //id
        $status = intval($request->param('status', 0)); //id
        if ($id == 0 || $status == 0) {
            return json(['code' => 2, 'msg' => '未指定信息']);
        }
        
        $MMemberWithdraw = new MMemberWithdraw();
        
        $info = $MMemberWithdraw->getInfo(['id'=>$id]);
        
        if($info['type'] == 0){
            return json(['code' => 2, 'msg' => '请选择通道']);
        }
        
        $MMember = new MMember();
        
        $member_info = $MMember->getInfo(['id'=>$info['uid']],'balance');
        
        $ban_info = Db::name('paymant_binding')->where('id',$info['bank_id'])->find();
        
        if($status == 3){
            
            if($info['type'] == 2){
            
                $url='http://api.letspayfast.com/apitrans';
                       
                $type="api";
                $mchId='1659604480553';//"1645869831193";
                $mchTransNo=$info['order_id'];
                $amount=$info['num'];
                $accountName=$ban_info['name']; //持卡人姓名
                $accountNo=$ban_info['bank_num']; // 持卡人卡号
                $bankCode=$ban_info['ifsc'];
                $notifyUrl='http://'.$_SERVER['HTTP_HOST'].'/api/paymenttwo/PaymentCallBack';
                $remarkInfo='email:'.$ban_info['tel'].'@gmail.com/phone:'.$ban_info['tel'].'/mode:bank';//"email:kakaka@google.com/name:tom/phone:91931340330";
    
                //$key='P0ppElfQMjVwQOveatzhkUWBAf9Yb9gyiLQcY3QOSqEQcD1FJpy85CXLY7rS7CHhG5J8n5oJ6HqIIuWdF16UNfmLzEzqtMBQDmxowi6gtnoEPewmQ7GIOPnDsYF8il3K';
                $key='Q37GPUIS7MRK7IFJ';
                
                //签名
                $sign_str = '';
                $sign_str  = $sign_str . 'accountName=' . $accountName;
                $sign_str  = $sign_str . '&accountNo=' . $accountNo;
                $sign_str  = $sign_str . '&amount=' . $amount;
                $sign_str  = $sign_str . '&bankCode=' . $bankCode;
                $sign_str  = $sign_str . '&mchId=' . $mchId;
                $sign_str  = $sign_str . '&mchTransNo=' . $mchTransNo;
                $sign_str  = $sign_str . '&notifyUrl=' . $notifyUrl;
                $sign_str  = $sign_str . '&remarkInfo=' . $remarkInfo;
                $sign_str  = $sign_str . '&type=' . $type;
                $sign_str  = $sign_str . '&key=' . $key;
                
                $sign = strtoupper(md5($sign_str));
                
                //var_dump($sign_str);//exit();
                //格式化
                //$data=sprintf("amount=%s&accountName=%s&accountNo=%s&bankCode=%s&mchId=%s&mchTransNo=%s&notifyUrl=%s&remarkInfo=%s&type==%s&sign=%s",
                $data=sprintf("accountName=%s&accountNo=%s&amount=%s&bankCode=%s&mchId=%s&mchTransNo=%s&notifyUrl=%s&remarkInfo=%s&type=%s&sign=%s",
                    $accountName,
                    $accountNo,
                    $amount,
                    $bankCode,
                    $mchId,
                    $mchTransNo,
                    $notifyUrl,
                    $remarkInfo,
                    $type,
                    $sign);
                
                
                $post_data = array(
                    'accountName' => $accountName,
                    'accountNo' => $accountNo,
                    'amount' => $amount,
                    'bankCode' => $bankCode,
                    'mchId' => $mchId,
                    'mchTransNo' => $mchTransNo,
                    'notifyUrl' => $notifyUrl,
                    'remarkInfo' => $remarkInfo,
                    'type' => $type,
                    'sign' => $sign
                );
                
                //post
                $resp=$this->send_post($url,$post_data);
                //print_r($resp);
                Db::name('pay_info')->insert(['text'=>'通道2发起提现：'.$sign_str,'time'=>date('Y-m-d H:i:s',time())]);
                Db::name('pay_info')->insert(['text'=>'通道2发起提现结果：'.$resp,'time'=>date('Y-m-d H:i:s',time())]);
                $data = json_decode($resp,true);
                
                if($data['retCode'] == 'SUCCESS'){
                    
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'hash'=>$data['mchTransNo'],
                        'status'=>3
                    ]);
                    
                    return json(['code' => 1, 'msg' => '成功，请等待处理']);
                }else{
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'status'=>0
                    ]);
                    return json(['code' => 2, 'msg' => $data['retMsg']]);
                }
            }elseif($info['type'] == 3){
            /*
                $param['memberid'] = '12300';
                $param['mobile'] = $info['tel'];
                $param['notifyurl'] = 'http://'.$_SERVER['HTTP_HOST'].'/api/paymentthree/PaymentCallBack';
                $param['orderid'] = $info['order_id'];
                $param['amount'] = $info['num'];//'100.00';
                $param['bankcode'] = 'ydsep';
                $param['email'] = $info['tel'].'@gmail.com';
                
                $param['ifsc'] = $ban_info['ifsc'];
                $param['cardnumber'] = $ban_info['bank_num'];
                $param['bankname'] = $ban_info['account_num'];//substr($ban_info['ifsc'], 0, 4);
                $param['accountname'] = $ban_info['name'];  
                
                ksort($param);
                //var_dump($param);echo '<br/>';echo '<br/>';
                $key = '5b1cyo88fgbb5zhvg6fjp8yj78vzsgz9';
                $string = $this->generateSignString($param,$key);
                //var_dump($string);echo '<br/>';echo '<br/>';
                $sign = strtoupper(md5($string));
                //$sign = md5($string);
                //var_dump($sign);exit();
              
                $param['sign'] = $sign;
                
                
                $url = "https://pay.yingshanghui.xyz/Pay-payment-draw.aspx";*/
            
                
                $api_pay_host = 'https://api.victory-pay.com/payweb/withdraw';
                $datas = [
                    'merchant_id' => '8000414',//商户id
                    'notify_url' => 'http://'.$_SERVER['HTTP_HOST'].'/api/paymentfour/PaymentCallBack',//回调地址
                    'mer_order_num' => $info['order_id'],//商家自己平台的订单号
                    'price' => $info['num'],//代付金额
                    'account_name' => $ban_info['name'],//用户银行账户名称
                    'account_num' => $ban_info['bank_num'],//用户银行账号
                    'account_bank' => $ban_info['account_num'],//银行名称
                    'remark' => $ban_info['ifsc'],//ifsc码
                    'timestamp' => time(),//时间错
                ];
                ksort($datas);
                $key = 'trzf73s6k9wyyvhed1sofkixljmexb2u';
                
                $string = $this->generateSignString($datas,$key);

                $sign = strtoupper(md5($string));
                
                $datas['sign'] = $sign;
                $datas['sign_type'] = 'MD5'; 
                
                $headers = [
                    'Content-Type:application/json'
                ];
                //var_dump($datas);exit();
                $curl = curl_init();
                $params[CURLOPT_URL] = 'https://api.victory-pay.com/payweb/withdraw';//'https://pay.yingshanghui.xyz/Pay-payment-draw.aspx?xxtest=1';
                $params[CURLOPT_HTTPHEADER] = $headers;
                $params[CURLOPT_RETURNTRANSFER] = true;
                $params[CURLOPT_FOLLOWLOCATION] = true;
                $params[CURLOPT_POST] = true;
                $params[CURLOPT_POSTFIELDS] = json_encode($datas);
                $params[CURLOPT_SSL_VERIFYPEER] = false;
                $params[CURLOPT_SSL_VERIFYHOST] = false;
                //$params[CURLOPT_CUSTOMREQUEST] = 'POST';
                //$params[CURLOPT_HTTP_VERSION] = 'CURL_HTTP_VERSION_1_1';
                //$param[CURLOPT_SSL_VERIFYPEER] = false;
                //$param[CURLOPT_SSL_VERIFYHOST] = false;
                curl_setopt_array($curl,$params); //传参数
                $data = curl_exec($curl);       //执行命令
                curl_close($curl);
                
                //$resp=$this->send_post($url,$param);
                //print_r($resp);
                //return $data;
                                
                Db::name('pay_info')->insert(['text'=>'发起提现3：'.$data,'time'=>date('Y-m-d H:i:s',time())]);
                $data = json_decode($data,true);
                
                if($data['code'] == 200){
                    //Db::name('pay_info')->insert(['text'=>'发起提现3：'.$data['msg']['transaction_id'],'time'=>date('Y-m-d H:i:s',time())]);
                    
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'hash'=>$info['order_id'],//$data['msg']['transaction_id'],
                        'status'=>3
                    ]);
                    
                    return json(['code' => 1, 'msg' => '成功，请等待处理']);
                }else{
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'status'=>0
                    ]);
                    return json(['code' => 2, 'msg' => $data['msg']]);
                }
                 
            }elseif($info['type'] == 4){
                
                $api_pay_host = 'https://payment.weglobalpayment.com/pay/transfer';
                $datas = [
                    'mch_id' => '100668666',//'100668003',//商户id
                    'mch_transferId' => $info['order_id'],//商家自己平台的订单号
                    'transfer_amount' => intval($info['num']),//代付金额
                    'apply_date' =>  date('Y-m-d H:i:s',time()),
                    'bank_code' => 'IDPT0001',//收款银行代码
                    'receive_name' => $ban_info['name'],//用户银行账户名称
                    'receive_account' => $ban_info['bank_num'],//用户银行账号
                    'remark' => $ban_info['ifsc'],//ifsc码
                    'back_url' => 'http://'.$_SERVER['HTTP_HOST'].'/api/paymentsix/PaymentCallBack',//回调地址
                ];
                ksort($datas);
                //var_dump($datas);exit();
                $key = 'COKKZ3UY8BZEYTOCRBQGNST77HSGIGXI';//'h7a2uvglvtefdj16zkfncroei4pmcpjx';
                
                $string = $this->generateSignString($datas,$key);

                $sign = md5($string);//strtoupper()
                
                $datas['sign'] = $sign;
                $datas['sign_type'] = 'MD5';
                //var_dump($datas);//exit();
                
                $ch = curl_init();    
                curl_setopt($ch,CURLOPT_URL,"https://payment.weglobalpayment.com/pay/transfer"); //支付请求地址
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HEADER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($datas));  
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
                $response=curl_exec($ch);
                //$res=simplexml_load_string($response);
                curl_close($ch);
            
                Db::name('pay_info')->insert(['text'=>'发起提现4：'.$response,'time'=>date('Y-m-d H:i:s',time())]);
                
                $data = json_decode($response,true);
            
                //$data = json_decode($data,true);
                
                /*if($data['code'] == 401){
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'status'=>0
                    ]);
                    return json(['code' => 2, 'msg' => $data['msg']]);
                }*/
                
                if($data['respCode'] == 'SUCCESS'){
                    //Db::name('pay_info')->insert(['text'=>'发起提现3：'.$data['msg']['transaction_id'],'time'=>date('Y-m-d H:i:s',time())]);
                    
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'hash'=>$data['tradeNo'],//$info['order_id'],//$data['msg']['transaction_id'],
                        'status'=>3
                    ]);
                    
                    return json(['code' => 1, 'msg' => '成功，请等待处理']);
                }else{
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'status'=>0
                    ]);
                    return json(['code' => 2, 'msg' => $data['errorMsg']]);
                }
            
            }else{
                
                
                
                $api_pay_host = 'https://api.victory-pay.com/payweb/withdraw';
                $datas = [
                    'merchant_id' => '8000413',//商户id
                    'notify_url' => 'http://'.$_SERVER['HTTP_HOST'].'/api/paymentfive/PaymentCallBack',//回调地址
                    'mer_order_num' => $info['order_id'],//商家自己平台的订单号
                    'price' => $info['num'],//代付金额
                    'account_name' => $ban_info['name'],//用户银行账户名称
                    'account_num' => $ban_info['bank_num'],//用户银行账号
                    'account_bank' => $ban_info['account_num'],//银行名称
                    'remark' => $ban_info['ifsc'],//ifsc码
                    'timestamp' => time(),//时间错
                ];
                
                ksort($datas);
                $key = 'fs8gzx6udeakyiigqcvemmc473ql5saj';
                
                $string = $this->generateSignString($datas,$key);
                
                $sign = strtoupper(md5($string));
                
                $datas['sign'] = $sign;
                $datas['sign_type'] = 'MD5';
                
                $headers = [
                    'Content-Type:application/json'
                ];
                //var_dump($datas);exit();
                $curl = curl_init();
                $params[CURLOPT_URL] = 'https://api.victory-pay.com/payweb/withdraw';//'https://pay.yingshanghui.xyz/Pay-payment-draw.aspx?xxtest=1';
                $params[CURLOPT_HTTPHEADER] = $headers;
                $params[CURLOPT_RETURNTRANSFER] = true;
                $params[CURLOPT_FOLLOWLOCATION] = true;
                $params[CURLOPT_POST] = true;
                $params[CURLOPT_POSTFIELDS] = json_encode($datas);
                $params[CURLOPT_SSL_VERIFYPEER] = false;
                $params[CURLOPT_SSL_VERIFYHOST] = false;
                //$params[CURLOPT_CUSTOMREQUEST] = 'POST';
                //$params[CURLOPT_HTTP_VERSION] = 'CURL_HTTP_VERSION_1_1';
                //$param[CURLOPT_SSL_VERIFYPEER] = false;
                //$param[CURLOPT_SSL_VERIFYHOST] = false;
                curl_setopt_array($curl,$params); //传参数
                $data = curl_exec($curl);       //执行命令
                curl_close($curl);
                
                //$resp=$this->send_post($url,$param);
                //print_r($resp);
                //return $data;
                
                Db::name('pay_info')->insert(['text'=>'发起提现1：'.$data,'time'=>date('Y-m-d H:i:s',time())]);
                $data = json_decode($data,true);
                
                if($data['code'] == 200){
                    //Db::name('pay_info')->insert(['text'=>'发起提现3：'.$data['msg']['transaction_id'],'time'=>date('Y-m-d H:i:s',time())]);
                    
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'hash'=>$info['order_id'],//$data['msg']['transaction_id'],
                        'status'=>3
                    ]);
                    
                    return json(['code' => 1, 'msg' => '成功，请等待处理']);
                }else{
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'status'=>0
                    ]);
                    return json(['code' => 2, 'msg' => $data['msg']]);
                }
                
                
                
            
                /*$data = [
                    'merchantLogin'=>'HX251',
                    'orderCode'=>$info['order_id'],
                    'amount'=>$info['num'],
                    'name'=>$ban_info['name'],
                    'account'=>$ban_info['bank_num'],
                    'ifsc'=>$ban_info['ifsc'],
                    'remark'=>'remark'
                ];
                
                ksort($data);
                
                $key = 'O12NqGSSCoecdiqZYIU5';
                $string = $this->generateSignString($data,$key);
                $sign = md5($string);
        
                $data['key'] = $key;
                $data['sign'] = $sign;
                
                //var_dump($data);exit();
        
                $url = "https://quartet.quartet.hxpayment.xyz/payment/payout";
                
                $headers = [
                    'Content-Type:application/json'
                ];
                
                $curl = curl_init();
                $param[CURLOPT_URL] = $url;
                $param[CURLOPT_HTTPHEADER] = $headers;
                $param[CURLOPT_RETURNTRANSFER] = true;
                $param[CURLOPT_FOLLOWLOCATION] = true;
                $param[CURLOPT_POST] = true;
                $param[CURLOPT_POSTFIELDS] = json_encode($data);
                $param[CURLOPT_SSL_VERIFYPEER] = false;
                $param[CURLOPT_SSL_VERIFYHOST] = false;
                curl_setopt_array($curl,$param); //传参数
                $data = curl_exec($curl);       //执行命令
                curl_close($curl);
                
                Db::name('pay_info')->insert(['text'=>'发起提现：'.$data,'time'=>date('Y-m-d H:i:s',time())]);
                $data = json_decode($data,true);
    
                if(!empty($data['platformOrderCode'])){
                    
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'hash'=>$data['platformOrderCode'],
                        'status'=>3
                    ]);
                    
                    return json(['code' => 1, 'msg' => '成功，请等待处理']);
                }else{
                    Db::name('member_bm_withdraw')->where('id',$id)->update([
                        'status'=>0
                    ]);
                    return json(['code' => 2, 'msg' => '服务器请求失败，请稍后再执行操作']);
                }*/
            
            }
        }else{
            try {
                Db::startTrans();
                
                Db::name('member_bm_withdraw')->where('id',$id)->update([
                    'update_time'=>time(),
                    'status'=>2
                ]);
                    
                Db::name('member_balance_log')->insert([
                    'u_id' => $info['uid'],
                    'tel' => $info['tel'],
                    'former_money' => $member_info['balance'],
                    'change_money' => $info['num'],
                    'after_money' => $member_info['balance'] + $info['num'],
                    'message' => '提现失败退回'.$info['num'],
                    'message_e' => 'Withdrawal failed and returned '.$info['num'],
                    'type' => 2,
                    'bo_time' => time(),
                    'status' => 91
                ]);
                
                Db::name('member_list')->where('id', $info['uid'])->update([
                    'balance' => Db::raw('balance +'.$info['num'])
                ]);
                            
                Db::commit();
                return json(['code' => 1,'msg' => '操作成功']);
            } catch (Exception $exception) {
                Db::rollback();
                return json(['code' => 2,'msg' => '操作失败 '.$exception->getMessage()]);
            }
        }
        

    }
    
    public function generateSignString($data,$key) {
        if (!empty($data)) {
            $string = '';
            foreach($data as $k => $v){
                $string .= $k.'='.$v.'&';
            }
        }
        $string .= 'key='.$key;
        return $string;
    }
    
        
    
    function send_post($url, $post_data) {
        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        return $result;
    }
        
    public function tmtypecheck(Request $request)
    {
        $MMemberWithdraw = new MMemberWithdraw();
        
        if ($request->isAjax()) {
            $id = intval($request->param('id', 0)); //id
            $type = intval($request->param('type', 0)); //id
            
            if(empty($id) || empty($type)){
                return json(['code' => 2,'msg' => '参数错误','data'=>[]]);
            }
            
            $res = $MMemberWithdraw->where('id',$id)->update(['type'=>$type]);
            if($res){
                return json(['code' => 1, 'msg' => '成功']);
            }
        }else{
            
            $MConfig = new MConfig();
            $config_val = $MConfig->readConfig(['PAY_ONE','PAY_TWO','PAY_ONE_NAME','PAY_TWO_NAME','PAY_THREE','PAY_THREE_NAME','PAY_FOUR','PAY_FOUR_NAME'],2);
            $data = [];
            if($config_val[0] == 1){
                $pay1 = $config_val[2];
            }else{
                $pay1 = $config_val[2].'-已关闭';
            }
            if($config_val[1] == 1){
                $pay2 = $config_val[3];
            }else{
                $pay2 = $config_val[3].'-已关闭';
            }
            if($config_val[4] == 1){
                $pay3 = $config_val[5];
            }else{
                $pay3 = $config_val[5].'-已关闭';
            }
            if($config_val[6] == 1){
                $pay4 = $config_val[7];
            }else{
                $pay4 = $config_val[7].'-已关闭';
            }
            
            $id = intval($request->param('id', 0)); //id
            if ($id == 0) {
                return json(['code' => 2, 'msg' => '未指定信息']);
            }
            
            $info = $MMemberWithdraw->getInfo(['id'=>$id]);
            
            $this->assign('member', $info);
            $this->assign('pay1', $pay1);
            $this->assign('pay2', $pay2);
            $this->assign('pay3', $pay3);
            $this->assign('pay4', $pay4);
            
            return view();
        }
        
    }
    
    
    public function checkordersub(Request $request){
        $MMemberWithdraw = new MMemberWithdraw();
        
        $id = intval($request->param('id', 0)); //id
        $status = intval($request->param('status', 0)); //id
        
        if(empty($id) || empty($status)){
            return json(['code' => 2,'msg' => '参数错误','data'=>[]]);
        }
        if($status != 1){
            return json(['code' => 2,'msg' => '订单状态错误','data'=>[]]);
        }
        // $res = $MMemberWithdraw->where('id',$id)->update(['type'=>$type]);
        // if($res){
        //     return json(['code' => 1, 'msg' => '成功']);
        // }
        
        
        $withdraw_info = Db::name('member_bm_withdraw')->where('id = '.$id)->find();
        if(empty($withdraw_info)){
            Db::name('pay_info')->insert(['text'=>'提现手动执行回调：未找到该订单！','time'=>date('Y-m-d H:i:s',time())]);
            return json(['code' => 2, 'msg' => '未找到该订单']);
            exit();
        }
                        
        if($withdraw_info['status'] != 0 && $withdraw_info['status'] != 3){
            Db::name('pay_info')->insert(['text'=>'提现手动执行回调：该订单已处理','time'=>date('Y-m-d H:i:s',time())]);
            return json(['code' => 2, 'msg' => '该订单已被处理']);
            exit();
        }
        
        $member_info = Db::name('member_list')->where('id',$withdraw_info['uid'])->field('id,tel,balance')->find();

        //预约开始
        try {
            Db::startTrans();

                $res = Db::name('member_bm_withdraw')->where('id',$id)->update([
                    'update_time'=>time(),
                    'status'=>1
                ]);
                
                Db::name('member_list')->where('id', $withdraw_info['uid'])->update([
                    'balance_total' => Db::raw('balance_total +'.$withdraw_info['num'])
                ]);
                
                Db::name('member_balance_log')->insert([
                    'u_id' => $withdraw_info['uid'],
                    'tel' => $member_info['tel'],
                    'former_money' => 0,
                    'change_money' => $withdraw_info['num'],
                    'after_money' => 0,
                    'message' => '提现成功'.$withdraw_info['num'],
                    'message_e' => 'Withdrawal Successful'.$withdraw_info['num'],
                    'type' => 2,
                    'bo_time' => getIndaiTime(time()),
                    'status' => 92
                ]);
            
            Db::commit();
            
            Db::name('pay_info')->insert(['text'=>'提现手动执行回调：'.$id.'完成。','time'=>date('Y-m-d H:i:s',time())]); 
            //echo 'OK';
            //return"OK";
            return json(['code' => 1,'msg' => '成功']);
        } catch (Exception $exception) {
            Db::rollback();
            Db::name('pay_info')->insert(['text'=>'提现手动执行回调：'.$id.'失败，原因：'.$exception->getMessage(),'time'=>date('Y-m-d H:i:s',time())]); 
            //echo 'OK';
            //return"OK";
            return json(['code' => 2,'msg' => '提现手动执行回调：'.$id.'失败，原因：'.$exception->getMessage()]);
        }
    }
    
}

